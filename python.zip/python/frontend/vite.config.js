import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const apiPort = process.env.VITE_API_PORT || 8000;

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/quote": `http://localhost:${apiPort}`,
      "/orders": `http://localhost:${apiPort}`,
      "/admin": `http://localhost:${apiPort}`,
    },
  },
});
