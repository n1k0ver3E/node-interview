export default function App() {
  return (
    <div>
      <h1>Order Service</h1>
      <p>Start building your pages here.</p>
    </div>
  );
}
