from fastapi import APIRouter, HTTPException

from app.models.dto import CartRequest, OrderRequest, QuoteResponse, OrderResponse
from app.repositories.catalog_repo import CatalogRepository
from app.repositories.order_repo import OrderRepository
from app.repositories.promo_repo import PromotionRepository
from app.services.cart_service import CartService
from app.services.checkout_service import CheckoutService
from app.services.pricing_service import PricingService
from app.services.promotion_engine import build_promotion_engine
from app.services.quote_service import QuoteService
from app.services.shipping_service import ShippingService

router = APIRouter()

catalog_repo = CatalogRepository()
promo_repo = PromotionRepository()
order_repo = OrderRepository()
cart_service = CartService(catalog_repo)
promotion_engine = build_promotion_engine()
pricing_service = PricingService(promotion_engine=promotion_engine, promotion_repository=promo_repo)
shipping_service = ShippingService()
quote_service = QuoteService(cart_service=cart_service, pricing_service=pricing_service, shipping_service=shipping_service)
checkout_service = CheckoutService(
    cart_service=cart_service,
    pricing_service=pricing_service,
    shipping_service=shipping_service,
    order_repository=order_repo,
)


@router.post("/quote", response_model=QuoteResponse)
def create_quote(request: CartRequest) -> QuoteResponse:
    try:
        return quote_service.create_quote(request)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/orders", response_model=OrderResponse)
def place_order(request: OrderRequest) -> OrderResponse:
    try:
        return checkout_service.place_order(request)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/admin/promotions")
def list_promotions() -> dict:
    return {"promotions": [promo.model_dump() for promo in promo_repo.list_active()]} 
