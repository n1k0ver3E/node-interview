from __future__ import annotations

from decimal import Decimal
from typing import Iterable

from pydantic import BaseModel, Field


class PriceTier(BaseModel):
    min_qty: int
    unit_price: Decimal


class Product(BaseModel):
    sku: str
    name: str
    category: str
    base_price: Decimal
    price_tiers: list[PriceTier] = Field(default_factory=list)
    taxable: bool = True
    shipping_class: str = "standard"

    def unit_price_for_quantity(self, quantity: int) -> Decimal:
        unit_price = self.base_price
        for tier in sorted(self.price_tiers, key=lambda item: item.min_qty):
            if quantity >= tier.min_qty:
                unit_price = tier.unit_price
        return unit_price


class CartLineInput(BaseModel):
    sku: str
    quantity: int


class EnrichedCartLine(BaseModel):
    sku: str
    product_name: str
    category: str
    quantity: int
    base_unit_price: Decimal
    effective_unit_price: Decimal
    taxable: bool
    shipping_class: str

    @property
    def line_subtotal(self) -> Decimal:
        return self.effective_unit_price * self.quantity


class AppliedPromotion(BaseModel):
    code: str
    description: str
    amount: Decimal


class Promotion(BaseModel):
    code: str
    kind: str
    description: str
    percent_off: Decimal | None = None
    eligible_skus: list[str] = Field(default_factory=list)
    eligible_categories: list[str] = Field(default_factory=list)


class PriceBreakdown(BaseModel):
    subtotal: Decimal
    discount: Decimal
    shipping: Decimal
    tax: Decimal
    total: Decimal
    applied_promotions: list[AppliedPromotion] = Field(default_factory=list)


class OrderRecord(BaseModel):
    order_id: str
    email: str
    coupon_code: str | None = None
    items: list[EnrichedCartLine]
    pricing: PriceBreakdown


class CartSnapshot(BaseModel):
    items: list[EnrichedCartLine]

    def total_quantity(self) -> int:
        return sum(item.quantity for item in self.items)

    def skus(self) -> Iterable[str]:
        for item in self.items:
            yield item.sku
