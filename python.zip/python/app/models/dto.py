from decimal import Decimal

from pydantic import BaseModel, EmailStr, Field


class CartItemRequest(BaseModel):
    sku: str
    quantity: int = Field(gt=0)


class CartRequest(BaseModel):
    items: list[CartItemRequest]
    coupon_code: str | None = None
    state: str = "CA"


class OrderRequest(CartRequest):
    email: EmailStr


class QuoteLineResponse(BaseModel):
    sku: str
    name: str
    quantity: int
    unit_price: Decimal
    line_subtotal: Decimal


class AppliedPromotionResponse(BaseModel):
    code: str
    description: str
    amount: Decimal


class QuoteResponse(BaseModel):
    items: list[QuoteLineResponse]
    subtotal: Decimal
    discount: Decimal
    shipping: Decimal
    tax: Decimal
    total: Decimal
    applied_promotions: list[AppliedPromotionResponse]


class OrderResponse(QuoteResponse):
    order_id: str
