from __future__ import annotations

from decimal import Decimal

from app.models.domain import CartSnapshot, PriceBreakdown
from app.repositories.promo_repo import PromotionRepository
from app.services.promotion_engine import PromotionEngine
from app.utils.money import quantize_money


class PricingService:
    TAX_RATES = {
        "CA": Decimal("0.0875"),
        "NY": Decimal("0.0880"),
        "TX": Decimal("0.0825"),
    }

    def __init__(self, promotion_engine: PromotionEngine, promotion_repository: PromotionRepository) -> None:
        self.promotion_engine = promotion_engine
        self.promotion_repository = promotion_repository

    def price_cart(self, cart: CartSnapshot, coupon_code: str | None, shipping_cost: Decimal, state: str) -> PriceBreakdown:
        subtotal = quantize_money(sum((item.line_subtotal for item in cart.items), start=Decimal("0.00")))

        applied_promotions = []
        discount = Decimal("0.00")
        promotion = self.promotion_repository.get_by_code(coupon_code)
        if coupon_code and not promotion:
            raise ValueError(f"Unknown coupon code: {coupon_code}")
        if promotion:
            discount, applied_promotions = self.promotion_engine.apply(promotion, cart.items)

        taxable_subtotal = sum((item.line_subtotal for item in cart.items if item.taxable), start=Decimal("0.00"))
        # Tax should apply after discount allocation, but current implementation simplifies
        # by taxing pre-discount taxable subtotal. Existing tests do not target this yet.
        tax_rate = self.TAX_RATES.get(state.upper(), Decimal("0.0500"))
        tax = quantize_money(taxable_subtotal * tax_rate)

        total = quantize_money(subtotal - discount + shipping_cost + tax)
        return PriceBreakdown(
            subtotal=subtotal,
            discount=quantize_money(discount),
            shipping=quantize_money(shipping_cost),
            tax=tax,
            total=total,
            applied_promotions=applied_promotions,
        )
