from __future__ import annotations

from app.models.dto import CartRequest, AppliedPromotionResponse, QuoteLineResponse, QuoteResponse
from app.services.cart_service import CartService
from app.services.pricing_service import PricingService
from app.services.shipping_service import ShippingService


class QuoteService:
    def __init__(self, cart_service: CartService, pricing_service: PricingService, shipping_service: ShippingService) -> None:
        self.cart_service = cart_service
        self.pricing_service = pricing_service
        self.shipping_service = shipping_service

    def create_quote(self, request: CartRequest) -> QuoteResponse:
        cart = self.cart_service.enrich_items(request.items)
        shipping_cost = self.shipping_service.calculate(cart)
        pricing = self.pricing_service.price_cart(
            cart=cart,
            coupon_code=request.coupon_code,
            shipping_cost=shipping_cost,
            state=request.state,
        )
        return QuoteResponse(
            items=[
                QuoteLineResponse(
                    sku=item.sku,
                    name=item.product_name,
                    quantity=item.quantity,
                    unit_price=item.effective_unit_price,
                    line_subtotal=item.line_subtotal,
                )
                for item in cart.items
            ],
            subtotal=pricing.subtotal,
            discount=pricing.discount,
            shipping=pricing.shipping,
            tax=pricing.tax,
            total=pricing.total,
            applied_promotions=[
                AppliedPromotionResponse(
                    code=promo.code,
                    description=promo.description,
                    amount=promo.amount,
                )
                for promo in pricing.applied_promotions
            ],
        )
