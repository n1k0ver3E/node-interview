from __future__ import annotations

from app.models.domain import CartSnapshot, EnrichedCartLine
from app.models.dto import CartItemRequest
from app.repositories.catalog_repo import CatalogRepository


class CartService:
    def __init__(self, catalog_repository: CatalogRepository) -> None:
        self.catalog_repository = catalog_repository

    def enrich_items(self, items: list[CartItemRequest]) -> CartSnapshot:
        """
        Turn input cart lines into enriched lines with pricing metadata.
        """
        enriched: list[EnrichedCartLine] = []
        for item in items:
            product = self.catalog_repository.get_product(item.sku)
            unit_price = product.unit_price_for_quantity(item.quantity)
            enriched.append(
                EnrichedCartLine(
                    sku=product.sku,
                    product_name=product.name,
                    category=product.category,
                    quantity=item.quantity,
                    base_unit_price=product.base_price,
                    effective_unit_price=unit_price,
                    taxable=product.taxable,
                    shipping_class=product.shipping_class,
                )
            )
        return CartSnapshot(items=enriched)
