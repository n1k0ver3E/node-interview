from __future__ import annotations

from app.models.domain import OrderRecord
from app.models.dto import AppliedPromotionResponse, OrderRequest, OrderResponse, QuoteLineResponse
from app.repositories.order_repo import OrderRepository
from app.services.cart_service import CartService
from app.services.pricing_service import PricingService
from app.services.shipping_service import ShippingService


class CheckoutService:
    def __init__(
        self,
        cart_service: CartService,
        pricing_service: PricingService,
        shipping_service: ShippingService,
        order_repository: OrderRepository,
    ) -> None:
        self.cart_service = cart_service
        self.pricing_service = pricing_service
        self.shipping_service = shipping_service
        self.order_repository = order_repository

    def place_order(self, request: OrderRequest) -> OrderResponse:
        cart = self.cart_service.enrich_items(request.items)
        shipping_cost = self.shipping_service.calculate(cart)
        pricing = self.pricing_service.price_cart(
            cart=cart,
            coupon_code=request.coupon_code,
            shipping_cost=shipping_cost,
            state=request.state,
        )
        order = OrderRecord(
            order_id=self.order_repository.next_id(),
            email=request.email,
            coupon_code=request.coupon_code,
            items=cart.items,
            pricing=pricing,
        )
        self.order_repository.save(order)

        return OrderResponse(
            order_id=order.order_id,
            items=[
                QuoteLineResponse(
                    sku=item.sku,
                    name=item.product_name,
                    quantity=item.quantity,
                    unit_price=item.effective_unit_price,
                    line_subtotal=item.line_subtotal,
                )
                for item in cart.items
            ],
            subtotal=pricing.subtotal,
            discount=pricing.discount,
            shipping=pricing.shipping,
            tax=pricing.tax,
            total=pricing.total,
            applied_promotions=[
                AppliedPromotionResponse(code=promo.code, description=promo.description, amount=promo.amount)
                for promo in pricing.applied_promotions
            ],
        )
