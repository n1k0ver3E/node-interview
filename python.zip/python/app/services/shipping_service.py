from __future__ import annotations

from decimal import Decimal

from app.models.domain import CartSnapshot
from app.utils.money import quantize_money


class ShippingService:
    def calculate(self, cart: CartSnapshot) -> Decimal:
        fragile_count = sum(item.quantity for item in cart.items if item.shipping_class == "fragile")
        apparel_count = sum(item.quantity for item in cart.items if item.shipping_class == "apparel")
        standard_count = sum(item.quantity for item in cart.items if item.shipping_class == "standard")
        light_count = sum(item.quantity for item in cart.items if item.shipping_class == "light")

        shipping = Decimal("5.00")
        shipping += Decimal(fragile_count) * Decimal("1.50")
        shipping += Decimal(apparel_count) * Decimal("0.75")
        shipping += Decimal(standard_count) * Decimal("1.00")
        shipping += Decimal(light_count) * Decimal("0.25")

        item_count = cart.total_quantity()
        if item_count >= 8:
            shipping -= Decimal("3.00")

        return quantize_money(max(shipping, Decimal("0.00")))
