from __future__ import annotations

from abc import ABC, abstractmethod
from collections import defaultdict
from decimal import Decimal

from app.models.domain import AppliedPromotion, EnrichedCartLine, Promotion
from app.utils.money import quantize_money


class PromotionStrategy(ABC):
    kind: str

    @abstractmethod
    def apply(self, promotion: Promotion, items: list[EnrichedCartLine]) -> tuple[Decimal, AppliedPromotion | None]:
        raise NotImplementedError


class OrderPercentStrategy(PromotionStrategy):
    kind = "order_percent"

    def apply(self, promotion: Promotion, items: list[EnrichedCartLine]) -> tuple[Decimal, AppliedPromotion | None]:
        subtotal = sum((item.line_subtotal for item in items), start=Decimal("0.00"))
        percent = (promotion.percent_off or Decimal("0")) / Decimal("100")
        amount = quantize_money(subtotal * percent)
        if amount <= 0:
            return Decimal("0.00"), None
        return amount, AppliedPromotion(code=promotion.code, description=promotion.description, amount=amount)


class CategoryPercentStrategy(PromotionStrategy):
    kind = "category_percent"

    def apply(self, promotion: Promotion, items: list[EnrichedCartLine]) -> tuple[Decimal, AppliedPromotion | None]:
        eligible_total = sum(
            (item.line_subtotal for item in items if item.category in promotion.eligible_categories),
            start=Decimal("0.00"),
        )
        percent = (promotion.percent_off or Decimal("0")) / Decimal("100")
        amount = quantize_money(eligible_total * percent)
        if amount <= 0:
            return Decimal("0.00"), None
        return amount, AppliedPromotion(code=promotion.code, description=promotion.description, amount=amount)


class SkuPercentStrategy(PromotionStrategy):
    kind = "sku_percent"

    def apply(self, promotion: Promotion, items: list[EnrichedCartLine]) -> tuple[Decimal, AppliedPromotion | None]:
        eligible_total = sum(
            (item.line_subtotal for item in items if item.sku in promotion.eligible_skus),
            start=Decimal("0.00"),
        )
        percent = (promotion.percent_off or Decimal("0")) / Decimal("100")
        amount = quantize_money(eligible_total * percent)
        if amount <= 0:
            return Decimal("0.00"), None
        return amount, AppliedPromotion(code=promotion.code, description=promotion.description, amount=amount)


class PromotionEngine:
    def __init__(self, strategies: list[PromotionStrategy]) -> None:
        self._strategies = {strategy.kind: strategy for strategy in strategies}

    def apply(self, promotion: Promotion, items: list[EnrichedCartLine]) -> tuple[Decimal, list[AppliedPromotion]]:
        strategy = self._strategies.get(promotion.kind)
        if not strategy:
            raise ValueError(f"Unsupported promotion kind: {promotion.kind}")
        amount, applied = strategy.apply(promotion, items)
        if not applied:
            return Decimal("0.00"), []
        return amount, [applied]


def build_promotion_engine() -> PromotionEngine:
    return PromotionEngine(
        strategies=[
            OrderPercentStrategy(),
            CategoryPercentStrategy(),
            SkuPercentStrategy(),
        ]
    )
