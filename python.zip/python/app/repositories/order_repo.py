from __future__ import annotations

from itertools import count

from app.models.domain import OrderRecord


class OrderRepository:
    def __init__(self) -> None:
        self._counter = count(1001)
        self._orders: list[OrderRecord] = []

    def save(self, order: OrderRecord) -> OrderRecord:
        self._orders.append(order)
        return order

    def next_id(self) -> str:
        return f"ORD-{next(self._counter)}"

    def list_orders(self) -> list[OrderRecord]:
        return list(self._orders)
