from __future__ import annotations

from decimal import Decimal

from app.models.domain import PriceTier, Product


class CatalogRepository:
    """In-memory product catalog used for the interview."""

    def __init__(self) -> None:
        self._products = {
            "TSHIRT": Product(
                sku="TSHIRT",
                name="Logo T-Shirt",
                category="apparel",
                base_price=Decimal("20.00"),
                price_tiers=[PriceTier(min_qty=3, unit_price=Decimal("18.00"))],
                taxable=True,
                shipping_class="apparel",
            ),
            "MUG": Product(
                sku="MUG",
                name="Ceramic Mug",
                category="drinkware",
                base_price=Decimal("16.00"),
                price_tiers=[],
                taxable=True,
                shipping_class="fragile",
            ),
            "CAP": Product(
                sku="CAP",
                name="Baseball Cap",
                category="apparel",
                base_price=Decimal("14.00"),
                price_tiers=[],
                taxable=True,
                shipping_class="apparel",
            ),
            "STICKER": Product(
                sku="STICKER",
                name="Sticker Pack",
                category="accessories",
                base_price=Decimal("4.00"),
                price_tiers=[PriceTier(min_qty=10, unit_price=Decimal("3.00"))],
                taxable=False,
                shipping_class="light",
            ),
        }
        self.get_product_call_count = 0
        self.get_products_by_skus_call_count = 0

    def get_product(self, sku: str) -> Product:
        self.get_product_call_count += 1
        try:
            return self._products[sku]
        except KeyError as exc:
            raise ValueError(f"Unknown SKU: {sku}") from exc

    def get_products_by_skus(self, skus: list[str]) -> dict[str, Product]:
        self.get_products_by_skus_call_count += 1
        result: dict[str, Product] = {}
        for sku in skus:
            result[sku] = self.get_product(sku)
        return result
