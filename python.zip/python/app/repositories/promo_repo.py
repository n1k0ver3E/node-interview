from decimal import Decimal

from app.models.domain import Promotion


class PromotionRepository:
    def __init__(self) -> None:
        self._promotions = {
            "SAVE10": Promotion(
                code="SAVE10",
                kind="order_percent",
                description="10% off the whole order",
                percent_off=Decimal("10"),
            ),
            "APPAREL20": Promotion(
                code="APPAREL20",
                kind="category_percent",
                description="20% off apparel items",
                percent_off=Decimal("20"),
                eligible_categories=["apparel"],
            ),
            "MUGFAN": Promotion(
                code="MUGFAN",
                kind="sku_percent",
                description="25% off mugs",
                percent_off=Decimal("25"),
                eligible_skus=["MUG"],
            ),
        }

    def get_by_code(self, code: str | None) -> Promotion | None:
        if not code:
            return None
        return self._promotions.get(code.upper())

    def list_active(self) -> list[Promotion]:
        return list(self._promotions.values())
