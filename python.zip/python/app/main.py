from fastapi import FastAPI

from app.api.routes import router


app = FastAPI(title="Commerce Checkout Service")
app.include_router(router)
