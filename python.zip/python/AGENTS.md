# Agent Guide for This Repository

## Project purpose
This is a small FastAPI checkout service with quote and order APIs.

## Commands
- Install: `pip install -r requirements.txt`
- Run tests: `pytest -q`
- Run app: `uvicorn app.main:app --reload`

## Important constraints
- Keep public API response fields stable.
- Avoid adding external services or databases.

## Where to look first
- API entrypoint: `app/main.py`
- Routes: `app/api/routes.py`
- Orchestration: `app/services/quote_service.py`, `app/services/checkout_service.py`
- Cart loading/enrichment: `app/services/cart_service.py`
- Pricing: `app/services/pricing_service.py`
- Promotions: `app/services/promotion_engine.py`
- Data sources: `app/repositories/catalog_repo.py`, `app/repositories/promo_repo.py`
