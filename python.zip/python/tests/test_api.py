from decimal import Decimal

from fastapi.testclient import TestClient

from app.main import app
from app.api.routes import cart_service

client = TestClient(app)


def test_basic_quote_without_coupon() -> None:
    response = client.post(
        "/quote",
        json={
            "items": [
                {"sku": "TSHIRT", "quantity": 1},
                {"sku": "MUG", "quantity": 1},
            ],
            "state": "CA",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["subtotal"] == "36.00"
    assert data["shipping"] == "7.25"
    assert data["tax"] == "3.15"
    assert data["total"] == "46.40"


def test_duplicate_skus_should_use_aggregate_quantity_for_tier_pricing() -> None:
    response = client.post(
        "/quote",
        json={
            "items": [
                {"sku": "TSHIRT", "quantity": 2},
                {"sku": "TSHIRT", "quantity": 2},
            ],
            "state": "CA",
        },
    )
    assert response.status_code == 200
    data = response.json()

    # Correct behavior: 4 shirts should unlock the 3+ tier, so all 4 should use $18.
    assert data["subtotal"] == "72.00"
    assert [item["line_subtotal"] for item in data["items"]] == ["36.00", "36.00"]


def test_invalid_coupon_returns_400() -> None:
    response = client.post(
        "/quote",
        json={
            "items": [{"sku": "MUG", "quantity": 1}],
            "coupon_code": "DOESNOTEXIST",
            "state": "CA",
        },
    )
    assert response.status_code == 400
    assert response.json()["detail"] == "Unknown coupon code: DOESNOTEXIST"


# def test_product_loading_should_batch_by_unique_sku_for_large_cart() -> None:
#     cart_service.catalog_repository.get_product_call_count = 0
#     cart_service.catalog_repository.get_products_by_skus_call_count = 0

#     response = client.post(
#         "/quote",
#         json={
#             "items": [
#                 {"sku": "TSHIRT", "quantity": 1},
#                 {"sku": "TSHIRT", "quantity": 2},
#                 {"sku": "MUG", "quantity": 1},
#                 {"sku": "CAP", "quantity": 1},
#                 {"sku": "CAP", "quantity": 2},
#                 {"sku": "STICKER", "quantity": 5},
#             ],
#             "state": "NY",
#         },
#     )

#     assert response.status_code == 200
#     # Desired behavior: one batched fetch for unique SKUs, not one repository call per line.
#     assert cart_service.catalog_repository.get_products_by_skus_call_count == 1
#     assert cart_service.catalog_repository.get_product_call_count <= 4


def test_order_endpoint_works_with_coupon_and_returns_order_id() -> None:
    response = client.post(
        "/orders",
        json={
            "email": "candidate@example.com",
            "items": [
                {"sku": "TSHIRT", "quantity": 1},
                {"sku": "CAP", "quantity": 1},
            ],
            "coupon_code": "APPAREL20",
            "state": "CA",
        },
    )
    assert response.status_code == 200
    data = response.json()
    assert data["order_id"].startswith("ORD-")
    assert data["discount"] == "6.80"

    # Correct behavior taxes discounted taxable amount, not pre-discount subtotal.
    assert data["tax"] == "2.38"
    assert data["total"] == "36.08"
