package com.example.orderservice.model.domain;

import java.util.List;
import java.util.stream.Collectors;

public class CartSnapshot {
    private List<EnrichedCartLine> items;

    public CartSnapshot() {}

    public CartSnapshot(List<EnrichedCartLine> items) {
        this.items = items;
    }

    public int totalQuantity() {
        return items.stream().mapToInt(EnrichedCartLine::getQuantity).sum();
    }

    public List<String> skus() {
        return items.stream().map(EnrichedCartLine::getSku).collect(Collectors.toList());
    }

    public List<EnrichedCartLine> getItems() { return items; }
    public void setItems(List<EnrichedCartLine> items) { this.items = items; }
}
