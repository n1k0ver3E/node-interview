package com.example.orderservice.model.domain;

import java.util.List;

public class OrderRecord {
    private String orderId;
    private String email;
    private String couponCode;
    private List<EnrichedCartLine> items;
    private PriceBreakdown pricing;

    public OrderRecord() {}

    public OrderRecord(String orderId, String email, String couponCode,
                       List<EnrichedCartLine> items, PriceBreakdown pricing) {
        this.orderId = orderId;
        this.email = email;
        this.couponCode = couponCode;
        this.items = items;
        this.pricing = pricing;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getCouponCode() { return couponCode; }
    public void setCouponCode(String couponCode) { this.couponCode = couponCode; }
    public List<EnrichedCartLine> getItems() { return items; }
    public void setItems(List<EnrichedCartLine> items) { this.items = items; }
    public PriceBreakdown getPricing() { return pricing; }
    public void setPricing(PriceBreakdown pricing) { this.pricing = pricing; }
}
