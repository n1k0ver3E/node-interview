package com.example.orderservice.service.promotion;

import com.example.orderservice.model.domain.AppliedPromotion;
import com.example.orderservice.model.domain.EnrichedCartLine;
import com.example.orderservice.model.domain.Promotion;
import com.example.orderservice.util.MoneyUtil;

import java.math.BigDecimal;
import java.util.List;

public class CategoryPercentStrategy implements PromotionStrategy {

    @Override
    public String getKind() {
        return "category_percent";
    }

    @Override
    public PromotionResult apply(Promotion promotion, List<EnrichedCartLine> items) {
        BigDecimal eligibleTotal = items.stream()
                .filter(item -> promotion.getEligibleCategories().contains(item.getCategory()))
                .map(EnrichedCartLine::getLineSubtotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal percent = (promotion.getPercentOff() != null ? promotion.getPercentOff() : BigDecimal.ZERO)
                .divide(new BigDecimal("100"));
        BigDecimal amount = MoneyUtil.quantizeMoney(eligibleTotal.multiply(percent));
        if (amount.compareTo(BigDecimal.ZERO) <= 0) {
            return new PromotionResult(BigDecimal.ZERO, null);
        }
        return new PromotionResult(amount, new AppliedPromotion(
                promotion.getCode(), promotion.getDescription(), amount));
    }
}
