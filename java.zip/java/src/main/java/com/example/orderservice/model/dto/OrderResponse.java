package com.example.orderservice.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.List;

public class OrderResponse extends QuoteResponse {
    @JsonProperty("order_id")
    private String orderId;

    public OrderResponse() {}

    public OrderResponse(String orderId, List<QuoteLineResponse> items, BigDecimal subtotal,
                         BigDecimal discount, BigDecimal shipping, BigDecimal tax, BigDecimal total,
                         List<AppliedPromotionResponse> appliedPromotions) {
        super(items, subtotal, discount, shipping, tax, total, appliedPromotions);
        this.orderId = orderId;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }
}
