package com.example.orderservice.model.domain;

import com.example.orderservice.util.MoneyUtil;

import java.math.BigDecimal;

public class EnrichedCartLine {
    private String sku;
    private String productName;
    private String category;
    private int quantity;
    private BigDecimal baseUnitPrice;
    private BigDecimal effectiveUnitPrice;
    private boolean taxable;
    private String shippingClass;

    public EnrichedCartLine() {}

    public EnrichedCartLine(String sku, String productName, String category, int quantity,
                            BigDecimal baseUnitPrice, BigDecimal effectiveUnitPrice,
                            boolean taxable, String shippingClass) {
        this.sku = sku;
        this.productName = productName;
        this.category = category;
        this.quantity = quantity;
        this.baseUnitPrice = baseUnitPrice;
        this.effectiveUnitPrice = effectiveUnitPrice;
        this.taxable = taxable;
        this.shippingClass = shippingClass;
    }

    public BigDecimal getLineSubtotal() {
        return MoneyUtil.quantizeMoney(effectiveUnitPrice.multiply(BigDecimal.valueOf(quantity)));
    }

    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public BigDecimal getBaseUnitPrice() { return baseUnitPrice; }
    public void setBaseUnitPrice(BigDecimal baseUnitPrice) { this.baseUnitPrice = baseUnitPrice; }
    public BigDecimal getEffectiveUnitPrice() { return effectiveUnitPrice; }
    public void setEffectiveUnitPrice(BigDecimal effectiveUnitPrice) { this.effectiveUnitPrice = effectiveUnitPrice; }
    public boolean isTaxable() { return taxable; }
    public void setTaxable(boolean taxable) { this.taxable = taxable; }
    public String getShippingClass() { return shippingClass; }
    public void setShippingClass(String shippingClass) { this.shippingClass = shippingClass; }
}
