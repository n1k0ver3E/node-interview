package com.example.orderservice.service;

import com.example.orderservice.model.domain.AppliedPromotion;
import com.example.orderservice.model.domain.CartSnapshot;
import com.example.orderservice.model.domain.PriceBreakdown;
import com.example.orderservice.model.domain.Promotion;
import com.example.orderservice.repository.PromotionRepository;
import com.example.orderservice.service.promotion.PromotionEngine;
import com.example.orderservice.util.MoneyUtil;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PricingService {

    private static final Map<String, BigDecimal> TAX_RATES = new HashMap<>();

    static {
        TAX_RATES.put("CA", new BigDecimal("0.0875"));
        TAX_RATES.put("NY", new BigDecimal("0.0880"));
        TAX_RATES.put("TX", new BigDecimal("0.0825"));
    }

    private final PromotionEngine promotionEngine;
    private final PromotionRepository promotionRepository;

    public PricingService(PromotionEngine promotionEngine, PromotionRepository promotionRepository) {
        this.promotionEngine = promotionEngine;
        this.promotionRepository = promotionRepository;
    }

    public PriceBreakdown priceCart(CartSnapshot cart, String couponCode, BigDecimal shippingCost, String state) {
        BigDecimal subtotal = MoneyUtil.quantizeMoney(
                cart.getItems().stream()
                        .map(item -> item.getLineSubtotal())
                        .reduce(BigDecimal.ZERO, BigDecimal::add)
        );

        List<AppliedPromotion> appliedPromotions = new ArrayList<>();
        BigDecimal discount = BigDecimal.ZERO;
        Promotion promotion = promotionRepository.getByCode(couponCode);
        if (couponCode != null && !couponCode.isBlank() && promotion == null) {
            throw new IllegalArgumentException("Unknown coupon code: " + couponCode);
        }
        if (promotion != null) {
            PromotionEngine.PromotionEngineResult result = promotionEngine.apply(promotion, cart.getItems());
            discount = result.discount();
            appliedPromotions = result.appliedPromotions();
        }

        BigDecimal taxableSubtotal = cart.getItems().stream()
                .filter(item -> item.isTaxable())
                .map(item -> item.getLineSubtotal())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        BigDecimal taxRate = TAX_RATES.getOrDefault(state.toUpperCase(), new BigDecimal("0.0500"));
        BigDecimal tax = MoneyUtil.quantizeMoney(taxableSubtotal.multiply(taxRate));

        BigDecimal total = MoneyUtil.quantizeMoney(
                subtotal.subtract(discount).add(shippingCost).add(tax)
        );

        return new PriceBreakdown(
                subtotal,
                MoneyUtil.quantizeMoney(discount),
                MoneyUtil.quantizeMoney(shippingCost),
                tax,
                total,
                appliedPromotions
        );
    }
}
