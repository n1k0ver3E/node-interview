package com.example.orderservice.service;

import com.example.orderservice.model.domain.CartSnapshot;
import com.example.orderservice.model.domain.PriceBreakdown;
import com.example.orderservice.model.dto.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.stream.Collectors;

@Service
public class QuoteService {

    private final CartService cartService;
    private final PricingService pricingService;
    private final ShippingService shippingService;

    public QuoteService(CartService cartService, PricingService pricingService, ShippingService shippingService) {
        this.cartService = cartService;
        this.pricingService = pricingService;
        this.shippingService = shippingService;
    }

    public QuoteResponse createQuote(CartRequest request) {
        CartSnapshot cart = cartService.enrichItems(request.getItems());
        BigDecimal shippingCost = shippingService.calculate(cart);
        PriceBreakdown pricing = pricingService.priceCart(
                cart, request.getCouponCode(), shippingCost, request.getState()
        );

        return new QuoteResponse(
                cart.getItems().stream().map(item -> new QuoteLineResponse(
                        item.getSku(),
                        item.getProductName(),
                        item.getQuantity(),
                        item.getEffectiveUnitPrice(),
                        item.getLineSubtotal()
                )).collect(Collectors.toList()),
                pricing.getSubtotal(),
                pricing.getDiscount(),
                pricing.getShipping(),
                pricing.getTax(),
                pricing.getTotal(),
                pricing.getAppliedPromotions().stream().map(promo -> new AppliedPromotionResponse(
                        promo.getCode(),
                        promo.getDescription(),
                        promo.getAmount()
                )).collect(Collectors.toList())
        );
    }
}
