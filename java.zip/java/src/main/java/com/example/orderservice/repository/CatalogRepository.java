package com.example.orderservice.repository;

import com.example.orderservice.model.domain.PriceTier;
import com.example.orderservice.model.domain.Product;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Repository
public class CatalogRepository {

    private final Map<String, Product> products = new HashMap<>();
    private int getProductCallCount = 0;
    private int getProductsBySkusCallCount = 0;

    public CatalogRepository() {
        products.put("TSHIRT", new Product(
                "TSHIRT", "Logo T-Shirt", "apparel", new BigDecimal("20.00"),
                List.of(new PriceTier(3, new BigDecimal("18.00"))),
                true, "apparel"
        ));
        products.put("MUG", new Product(
                "MUG", "Ceramic Mug", "drinkware", new BigDecimal("16.00"),
                List.of(),
                true, "fragile"
        ));
        products.put("CAP", new Product(
                "CAP", "Baseball Cap", "apparel", new BigDecimal("14.00"),
                List.of(),
                true, "apparel"
        ));
        products.put("STICKER", new Product(
                "STICKER", "Sticker Pack", "accessories", new BigDecimal("4.00"),
                List.of(new PriceTier(10, new BigDecimal("3.00"))),
                false, "light"
        ));
    }

    public Product getProduct(String sku) {
        getProductCallCount++;
        Product product = products.get(sku);
        if (product == null) {
            throw new IllegalArgumentException("Unknown SKU: " + sku);
        }
        return product;
    }

    public Map<String, Product> getProductsBySkus(List<String> skus) {
        getProductsBySkusCallCount++;
        Map<String, Product> result = new LinkedHashMap<>();
        for (String sku : skus) {
            result.put(sku, getProduct(sku));
        }
        return result;
    }

    public int getGetProductCallCount() { return getProductCallCount; }
    public void setGetProductCallCount(int count) { this.getProductCallCount = count; }
    public int getGetProductsBySkusCallCount() { return getProductsBySkusCallCount; }
    public void setGetProductsBySkusCallCount(int count) { this.getProductsBySkusCallCount = count; }
}
