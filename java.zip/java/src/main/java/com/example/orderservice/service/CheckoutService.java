package com.example.orderservice.service;

import com.example.orderservice.model.domain.CartSnapshot;
import com.example.orderservice.model.domain.OrderRecord;
import com.example.orderservice.model.domain.PriceBreakdown;
import com.example.orderservice.model.dto.*;
import com.example.orderservice.repository.OrderRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.stream.Collectors;

@Service
public class CheckoutService {

    private final CartService cartService;
    private final PricingService pricingService;
    private final ShippingService shippingService;
    private final OrderRepository orderRepository;

    public CheckoutService(CartService cartService, PricingService pricingService,
                           ShippingService shippingService, OrderRepository orderRepository) {
        this.cartService = cartService;
        this.pricingService = pricingService;
        this.shippingService = shippingService;
        this.orderRepository = orderRepository;
    }

    public OrderResponse placeOrder(OrderRequest request) {
        CartSnapshot cart = cartService.enrichItems(request.getItems());
        BigDecimal shippingCost = shippingService.calculate(cart);
        PriceBreakdown pricing = pricingService.priceCart(
                cart, request.getCouponCode(), shippingCost, request.getState()
        );

        OrderRecord order = new OrderRecord(
                orderRepository.nextId(),
                request.getEmail(),
                request.getCouponCode(),
                cart.getItems(),
                pricing
        );
        orderRepository.save(order);

        return new OrderResponse(
                order.getOrderId(),
                cart.getItems().stream().map(item -> new QuoteLineResponse(
                        item.getSku(),
                        item.getProductName(),
                        item.getQuantity(),
                        item.getEffectiveUnitPrice(),
                        item.getLineSubtotal()
                )).collect(Collectors.toList()),
                pricing.getSubtotal(),
                pricing.getDiscount(),
                pricing.getShipping(),
                pricing.getTax(),
                pricing.getTotal(),
                pricing.getAppliedPromotions().stream().map(promo -> new AppliedPromotionResponse(
                        promo.getCode(),
                        promo.getDescription(),
                        promo.getAmount()
                )).collect(Collectors.toList())
        );
    }
}
