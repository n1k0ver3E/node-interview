package com.example.orderservice.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public final class MoneyUtil {
    private MoneyUtil() {}

    public static BigDecimal quantizeMoney(BigDecimal value) {
        return value.setScale(2, RoundingMode.HALF_UP);
    }
}
