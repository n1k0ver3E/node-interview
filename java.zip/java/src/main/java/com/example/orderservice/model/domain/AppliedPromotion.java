package com.example.orderservice.model.domain;

import java.math.BigDecimal;

public class AppliedPromotion {
    private String code;
    private String description;
    private BigDecimal amount;

    public AppliedPromotion() {}

    public AppliedPromotion(String code, String description, BigDecimal amount) {
        this.code = code;
        this.description = description;
        this.amount = amount;
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
}
