package com.example.orderservice.repository;

import com.example.orderservice.model.domain.OrderRecord;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@Repository
public class OrderRepository {

    private final AtomicInteger counter = new AtomicInteger(1001);
    private final List<OrderRecord> orders = new ArrayList<>();

    public OrderRecord save(OrderRecord order) {
        orders.add(order);
        return order;
    }

    public String nextId() {
        return "ORD-" + counter.getAndIncrement();
    }

    public List<OrderRecord> listOrders() {
        return new ArrayList<>(orders);
    }
}
