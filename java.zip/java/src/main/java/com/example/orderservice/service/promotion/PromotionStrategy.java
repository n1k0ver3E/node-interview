package com.example.orderservice.service.promotion;

import com.example.orderservice.model.domain.AppliedPromotion;
import com.example.orderservice.model.domain.EnrichedCartLine;
import com.example.orderservice.model.domain.Promotion;

import java.math.BigDecimal;
import java.util.List;

public interface PromotionStrategy {
    String getKind();
    PromotionResult apply(Promotion promotion, List<EnrichedCartLine> items);

    record PromotionResult(BigDecimal amount, AppliedPromotion appliedPromotion) {}
}
