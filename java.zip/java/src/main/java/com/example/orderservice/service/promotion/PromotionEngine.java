package com.example.orderservice.service.promotion;

import com.example.orderservice.model.domain.AppliedPromotion;
import com.example.orderservice.model.domain.EnrichedCartLine;
import com.example.orderservice.model.domain.Promotion;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PromotionEngine {

    private final Map<String, PromotionStrategy> strategies = new HashMap<>();

    public PromotionEngine(List<PromotionStrategy> strategyList) {
        for (PromotionStrategy strategy : strategyList) {
            strategies.put(strategy.getKind(), strategy);
        }
    }

    public PromotionEngineResult apply(Promotion promotion, List<EnrichedCartLine> items) {
        PromotionStrategy strategy = strategies.get(promotion.getKind());
        if (strategy == null) {
            throw new IllegalArgumentException("Unsupported promotion kind: " + promotion.getKind());
        }
        PromotionStrategy.PromotionResult result = strategy.apply(promotion, items);
        if (result.appliedPromotion() == null) {
            return new PromotionEngineResult(BigDecimal.ZERO, List.of());
        }
        return new PromotionEngineResult(result.amount(), List.of(result.appliedPromotion()));
    }

    public record PromotionEngineResult(BigDecimal discount, List<AppliedPromotion> appliedPromotions) {}

    public static PromotionEngine buildPromotionEngine() {
        return new PromotionEngine(List.of(
                new OrderPercentStrategy(),
                new CategoryPercentStrategy(),
                new SkuPercentStrategy()
        ));
    }
}
