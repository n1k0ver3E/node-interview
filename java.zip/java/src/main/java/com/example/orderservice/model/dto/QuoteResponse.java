package com.example.orderservice.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.List;

public class QuoteResponse {
    private List<QuoteLineResponse> items;
    private BigDecimal subtotal;
    private BigDecimal discount;
    private BigDecimal shipping;
    private BigDecimal tax;
    private BigDecimal total;

    @JsonProperty("applied_promotions")
    private List<AppliedPromotionResponse> appliedPromotions;

    public QuoteResponse() {}

    public QuoteResponse(List<QuoteLineResponse> items, BigDecimal subtotal, BigDecimal discount,
                         BigDecimal shipping, BigDecimal tax, BigDecimal total,
                         List<AppliedPromotionResponse> appliedPromotions) {
        this.items = items;
        this.subtotal = subtotal;
        this.discount = discount;
        this.shipping = shipping;
        this.tax = tax;
        this.total = total;
        this.appliedPromotions = appliedPromotions;
    }

    public List<QuoteLineResponse> getItems() { return items; }
    public void setItems(List<QuoteLineResponse> items) { this.items = items; }
    public BigDecimal getSubtotal() { return subtotal; }
    public void setSubtotal(BigDecimal subtotal) { this.subtotal = subtotal; }
    public BigDecimal getDiscount() { return discount; }
    public void setDiscount(BigDecimal discount) { this.discount = discount; }
    public BigDecimal getShipping() { return shipping; }
    public void setShipping(BigDecimal shipping) { this.shipping = shipping; }
    public BigDecimal getTax() { return tax; }
    public void setTax(BigDecimal tax) { this.tax = tax; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal total) { this.total = total; }
    public List<AppliedPromotionResponse> getAppliedPromotions() { return appliedPromotions; }
    public void setAppliedPromotions(List<AppliedPromotionResponse> appliedPromotions) { this.appliedPromotions = appliedPromotions; }
}
