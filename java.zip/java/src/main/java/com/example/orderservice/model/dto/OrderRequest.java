package com.example.orderservice.model.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

import java.util.List;

public class OrderRequest extends CartRequest {
    @NotBlank
    @Email
    private String email;

    public OrderRequest() {}

    public OrderRequest(List<CartItemRequest> items, String couponCode, String state, String email) {
        super(items, couponCode, state);
        this.email = email;
    }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
