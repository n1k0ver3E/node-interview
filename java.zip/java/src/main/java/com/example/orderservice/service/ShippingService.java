package com.example.orderservice.service;

import com.example.orderservice.model.domain.CartSnapshot;
import com.example.orderservice.util.MoneyUtil;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class ShippingService {

    public BigDecimal calculate(CartSnapshot cart) {
        int fragileCount = cart.getItems().stream()
                .filter(i -> "fragile".equals(i.getShippingClass()))
                .mapToInt(i -> i.getQuantity()).sum();
        int apparelCount = cart.getItems().stream()
                .filter(i -> "apparel".equals(i.getShippingClass()))
                .mapToInt(i -> i.getQuantity()).sum();
        int standardCount = cart.getItems().stream()
                .filter(i -> "standard".equals(i.getShippingClass()))
                .mapToInt(i -> i.getQuantity()).sum();
        int lightCount = cart.getItems().stream()
                .filter(i -> "light".equals(i.getShippingClass()))
                .mapToInt(i -> i.getQuantity()).sum();

        BigDecimal shipping = new BigDecimal("5.00");
        shipping = shipping.add(new BigDecimal(fragileCount).multiply(new BigDecimal("1.50")));
        shipping = shipping.add(new BigDecimal(apparelCount).multiply(new BigDecimal("0.75")));
        shipping = shipping.add(new BigDecimal(standardCount).multiply(new BigDecimal("1.00")));
        shipping = shipping.add(new BigDecimal(lightCount).multiply(new BigDecimal("0.25")));

        int itemCount = cart.totalQuantity();
        if (itemCount >= 8) {
            shipping = shipping.subtract(new BigDecimal("3.00"));
        }

        return MoneyUtil.quantizeMoney(shipping.max(BigDecimal.ZERO));
    }
}
