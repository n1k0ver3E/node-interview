package com.example.orderservice.model.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PriceBreakdown {
    private BigDecimal subtotal;
    private BigDecimal discount;
    private BigDecimal shipping;
    private BigDecimal tax;
    private BigDecimal total;
    private List<AppliedPromotion> appliedPromotions = new ArrayList<>();

    public PriceBreakdown() {}

    public PriceBreakdown(BigDecimal subtotal, BigDecimal discount, BigDecimal shipping,
                          BigDecimal tax, BigDecimal total, List<AppliedPromotion> appliedPromotions) {
        this.subtotal = subtotal;
        this.discount = discount;
        this.shipping = shipping;
        this.tax = tax;
        this.total = total;
        this.appliedPromotions = appliedPromotions != null ? appliedPromotions : new ArrayList<>();
    }

    public BigDecimal getSubtotal() { return subtotal; }
    public void setSubtotal(BigDecimal subtotal) { this.subtotal = subtotal; }
    public BigDecimal getDiscount() { return discount; }
    public void setDiscount(BigDecimal discount) { this.discount = discount; }
    public BigDecimal getShipping() { return shipping; }
    public void setShipping(BigDecimal shipping) { this.shipping = shipping; }
    public BigDecimal getTax() { return tax; }
    public void setTax(BigDecimal tax) { this.tax = tax; }
    public BigDecimal getTotal() { return total; }
    public void setTotal(BigDecimal total) { this.total = total; }
    public List<AppliedPromotion> getAppliedPromotions() { return appliedPromotions; }
    public void setAppliedPromotions(List<AppliedPromotion> appliedPromotions) { this.appliedPromotions = appliedPromotions; }
}
