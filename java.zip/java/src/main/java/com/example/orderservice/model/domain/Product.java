package com.example.orderservice.model.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Product {
    private String sku;
    private String name;
    private String category;
    private BigDecimal basePrice;
    private List<PriceTier> priceTiers = new ArrayList<>();
    private boolean taxable = true;
    private String shippingClass = "standard";

    public Product() {}

    public Product(String sku, String name, String category, BigDecimal basePrice,
                   List<PriceTier> priceTiers, boolean taxable, String shippingClass) {
        this.sku = sku;
        this.name = name;
        this.category = category;
        this.basePrice = basePrice;
        this.priceTiers = priceTiers != null ? priceTiers : new ArrayList<>();
        this.taxable = taxable;
        this.shippingClass = shippingClass;
    }

    public BigDecimal unitPriceForQuantity(int quantity) {
        BigDecimal unitPrice = basePrice;
        List<PriceTier> sorted = priceTiers.stream()
                .sorted(Comparator.comparingInt(PriceTier::getMinQty))
                .toList();
        for (PriceTier tier : sorted) {
            if (quantity >= tier.getMinQty()) {
                unitPrice = tier.getUnitPrice();
            }
        }
        return unitPrice;
    }

    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    public BigDecimal getBasePrice() { return basePrice; }
    public void setBasePrice(BigDecimal basePrice) { this.basePrice = basePrice; }
    public List<PriceTier> getPriceTiers() { return priceTiers; }
    public void setPriceTiers(List<PriceTier> priceTiers) { this.priceTiers = priceTiers; }
    public boolean isTaxable() { return taxable; }
    public void setTaxable(boolean taxable) { this.taxable = taxable; }
    public String getShippingClass() { return shippingClass; }
    public void setShippingClass(String shippingClass) { this.shippingClass = shippingClass; }
}
