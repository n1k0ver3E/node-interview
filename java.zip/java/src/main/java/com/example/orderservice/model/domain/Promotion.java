package com.example.orderservice.model.domain;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Promotion {
    private String code;
    private String kind;
    private String description;
    private BigDecimal percentOff;
    private List<String> eligibleSkus = new ArrayList<>();
    private List<String> eligibleCategories = new ArrayList<>();

    public Promotion() {}

    public Promotion(String code, String kind, String description, BigDecimal percentOff,
                     List<String> eligibleSkus, List<String> eligibleCategories) {
        this.code = code;
        this.kind = kind;
        this.description = description;
        this.percentOff = percentOff;
        this.eligibleSkus = eligibleSkus != null ? eligibleSkus : new ArrayList<>();
        this.eligibleCategories = eligibleCategories != null ? eligibleCategories : new ArrayList<>();
    }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getKind() { return kind; }
    public void setKind(String kind) { this.kind = kind; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public BigDecimal getPercentOff() { return percentOff; }
    public void setPercentOff(BigDecimal percentOff) { this.percentOff = percentOff; }
    public List<String> getEligibleSkus() { return eligibleSkus; }
    public void setEligibleSkus(List<String> eligibleSkus) { this.eligibleSkus = eligibleSkus; }
    public List<String> getEligibleCategories() { return eligibleCategories; }
    public void setEligibleCategories(List<String> eligibleCategories) { this.eligibleCategories = eligibleCategories; }
}
