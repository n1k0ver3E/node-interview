package com.example.orderservice.repository;

import com.example.orderservice.model.domain.Promotion;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class PromotionRepository {

    private final Map<String, Promotion> promotions = new HashMap<>();

    public PromotionRepository() {
        promotions.put("SAVE10", new Promotion(
                "SAVE10", "order_percent", "10% off the whole order",
                new BigDecimal("10"), null, null
        ));
        promotions.put("APPAREL20", new Promotion(
                "APPAREL20", "category_percent", "20% off apparel items",
                new BigDecimal("20"), null, List.of("apparel")
        ));
        promotions.put("MUGFAN", new Promotion(
                "MUGFAN", "sku_percent", "25% off mugs",
                new BigDecimal("25"), List.of("MUG"), null
        ));
    }

    public Promotion getByCode(String code) {
        if (code == null || code.isBlank()) {
            return null;
        }
        return promotions.get(code.toUpperCase());
    }

    public List<Promotion> listActive() {
        return new ArrayList<>(promotions.values());
    }
}
