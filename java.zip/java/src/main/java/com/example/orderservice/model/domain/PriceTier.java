package com.example.orderservice.model.domain;

import java.math.BigDecimal;

public class PriceTier {
    private int minQty;
    private BigDecimal unitPrice;

    public PriceTier() {}

    public PriceTier(int minQty, BigDecimal unitPrice) {
        this.minQty = minQty;
        this.unitPrice = unitPrice;
    }

    public int getMinQty() { return minQty; }
    public void setMinQty(int minQty) { this.minQty = minQty; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }
}
