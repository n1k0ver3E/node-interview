package com.example.orderservice.controller;

import com.example.orderservice.model.domain.Promotion;
import com.example.orderservice.model.dto.CartRequest;
import com.example.orderservice.model.dto.OrderRequest;
import com.example.orderservice.model.dto.OrderResponse;
import com.example.orderservice.model.dto.QuoteResponse;
import com.example.orderservice.repository.PromotionRepository;
import com.example.orderservice.service.CartService;
import com.example.orderservice.service.CheckoutService;
import com.example.orderservice.service.QuoteService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
public class OrderController {

    private final QuoteService quoteService;
    private final CheckoutService checkoutService;
    private final PromotionRepository promotionRepository;
    private final CartService cartService;

    public OrderController(QuoteService quoteService, CheckoutService checkoutService,
                           PromotionRepository promotionRepository, CartService cartService) {
        this.quoteService = quoteService;
        this.checkoutService = checkoutService;
        this.promotionRepository = promotionRepository;
        this.cartService = cartService;
    }

    @PostMapping("/quote")
    public ResponseEntity<?> createQuote(@Valid @RequestBody CartRequest request) {
        try {
            return ResponseEntity.ok(quoteService.createQuote(request));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("detail", e.getMessage()));
        }
    }

    @PostMapping("/orders")
    public ResponseEntity<?> placeOrder(@Valid @RequestBody OrderRequest request) {
        try {
            return ResponseEntity.ok(checkoutService.placeOrder(request));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("detail", e.getMessage()));
        }
    }

    @GetMapping("/admin/promotions")
    public Map<String, Object> listPromotions() {
        List<Promotion> promos = promotionRepository.listActive();
        Map<String, Object> result = new HashMap<>();
        result.put("promotions", promos);
        return result;
    }

    public CartService getCartService() {
        return cartService;
    }
}
