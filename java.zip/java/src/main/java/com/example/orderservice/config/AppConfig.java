package com.example.orderservice.config;

import com.example.orderservice.service.promotion.PromotionEngine;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {

    @Bean
    public PromotionEngine promotionEngine() {
        return PromotionEngine.buildPromotionEngine();
    }
}
