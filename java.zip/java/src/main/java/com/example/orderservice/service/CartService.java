package com.example.orderservice.service;

import com.example.orderservice.model.domain.CartSnapshot;
import com.example.orderservice.model.domain.EnrichedCartLine;
import com.example.orderservice.model.domain.Product;
import com.example.orderservice.model.dto.CartItemRequest;
import com.example.orderservice.repository.CatalogRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {

    private final CatalogRepository catalogRepository;

    public CartService(CatalogRepository catalogRepository) {
        this.catalogRepository = catalogRepository;
    }

    public CartSnapshot enrichItems(List<CartItemRequest> items) {
        List<EnrichedCartLine> enriched = new ArrayList<>();
        for (CartItemRequest item : items) {
            Product product = catalogRepository.getProduct(item.getSku());
            BigDecimal unitPrice = product.unitPriceForQuantity(item.getQuantity());
            enriched.add(new EnrichedCartLine(
                    product.getSku(),
                    product.getName(),
                    product.getCategory(),
                    item.getQuantity(),
                    product.getBasePrice(),
                    unitPrice,
                    product.isTaxable(),
                    product.getShippingClass()
            ));
        }
        return new CartSnapshot(enriched);
    }

    public CatalogRepository getCatalogRepository() {
        return catalogRepository;
    }
}
