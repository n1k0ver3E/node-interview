package com.example.orderservice.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;

import java.util.List;

public class CartRequest {
    @NotEmpty
    @Valid
    private List<CartItemRequest> items;

    @JsonProperty("coupon_code")
    private String couponCode;

    private String state = "CA";

    public CartRequest() {}

    public CartRequest(List<CartItemRequest> items, String couponCode, String state) {
        this.items = items;
        this.couponCode = couponCode;
        this.state = state != null ? state : "CA";
    }

    public List<CartItemRequest> getItems() { return items; }
    public void setItems(List<CartItemRequest> items) { this.items = items; }
    public String getCouponCode() { return couponCode; }
    public void setCouponCode(String couponCode) { this.couponCode = couponCode; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
}
