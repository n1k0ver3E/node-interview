package com.example.orderservice;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ApiTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testBasicQuoteWithoutCoupon() throws Exception {
        String requestBody = """
                {
                    "items": [
                        {"sku": "TSHIRT", "quantity": 1},
                        {"sku": "MUG", "quantity": 1}
                    ],
                    "state": "CA"
                }
                """;

        MvcResult result = mockMvc.perform(post("/quote")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andReturn();

        JsonNode data = objectMapper.readTree(result.getResponse().getContentAsString());
        assertEquals("36.00", data.get("subtotal").asText());
        assertEquals("7.25", data.get("shipping").asText());
        assertEquals("3.15", data.get("tax").asText());
        assertEquals("46.40", data.get("total").asText());
    }

    @Test
    void testDuplicateSkusShouldUseAggregateQuantityForTierPricing() throws Exception {
        String requestBody = """
                {
                    "items": [
                        {"sku": "TSHIRT", "quantity": 2},
                        {"sku": "TSHIRT", "quantity": 2}
                    ],
                    "state": "CA"
                }
                """;

        MvcResult result = mockMvc.perform(post("/quote")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andReturn();

        JsonNode data = objectMapper.readTree(result.getResponse().getContentAsString());

        // Correct behavior: 4 shirts should unlock the 3+ tier, so all 4 should use $18.
        assertEquals("72.00", data.get("subtotal").asText());
        assertEquals("36.00", data.get("items").get(0).get("line_subtotal").asText());
        assertEquals("36.00", data.get("items").get(1).get("line_subtotal").asText());
    }

    @Test
    void testInvalidCouponReturns400() throws Exception {
        String requestBody = """
                {
                    "items": [{"sku": "MUG", "quantity": 1}],
                    "coupon_code": "DOESNOTEXIST",
                    "state": "CA"
                }
                """;

        MvcResult result = mockMvc.perform(post("/quote")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isBadRequest())
                .andReturn();

        JsonNode data = objectMapper.readTree(result.getResponse().getContentAsString());
        assertEquals("Unknown coupon code: DOESNOTEXIST", data.get("detail").asText());
    }

    // void testProductLoadingShouldBatchByUniqueSkuForLargeCart() throws Exception {
    //     // Reset counters
    //     // cartService.getCatalogRepository().setGetProductCallCount(0);
    //     // cartService.getCatalogRepository().setGetProductsBySkusCallCount(0);

    //     String requestBody = """
    //             {
    //                 "items": [
    //                     {"sku": "TSHIRT", "quantity": 1},
    //                     {"sku": "TSHIRT", "quantity": 2},
    //                     {"sku": "MUG", "quantity": 1},
    //                     {"sku": "CAP", "quantity": 1},
    //                     {"sku": "CAP", "quantity": 2},
    //                     {"sku": "STICKER", "quantity": 5}
    //                 ],
    //                 "state": "NY"
    //             }
    //             """;

    //     MvcResult result = mockMvc.perform(post("/quote")
    //                     .contentType(MediaType.APPLICATION_JSON)
    //                     .content(requestBody))
    //             .andExpect(status().isOk())
    //             .andReturn();

    //     // Desired behavior: one batched fetch for unique SKUs, not one repository call per line.
    //     // assertEquals(1, cartService.getCatalogRepository().getGetProductsBySkusCallCount());
    //     // assertTrue(cartService.getCatalogRepository().getGetProductCallCount() <= 4);
    // }

    @Test
    void testOrderEndpointWorksWithCouponAndReturnsOrderId() throws Exception {
        String requestBody = """
                {
                    "email": "candidate@example.com",
                    "items": [
                        {"sku": "TSHIRT", "quantity": 1},
                        {"sku": "CAP", "quantity": 1}
                    ],
                    "coupon_code": "APPAREL20",
                    "state": "CA"
                }
                """;

        MvcResult result = mockMvc.perform(post("/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody))
                .andExpect(status().isOk())
                .andReturn();

        JsonNode data = objectMapper.readTree(result.getResponse().getContentAsString());
        assertTrue(data.get("order_id").asText().startsWith("ORD-"));
        assertEquals("6.80", data.get("discount").asText());

        // Correct behavior taxes discounted taxable amount, not pre-discount subtotal.
        assertEquals("2.38", data.get("tax").asText());
        assertEquals("36.08", data.get("total").asText());
    }
}
