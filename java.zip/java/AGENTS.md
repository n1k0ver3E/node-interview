# Agent Guide for This Repository

## Project purpose
This is a small Spring Boot checkout service with quote and order APIs.

## Commands
- Build: `mvn compile`
- Run tests: `mvn test`
- Run app: `mvn spring-boot:run`

## Important constraints
- Keep public API response fields stable.
- Avoid adding external services or databases.

## Where to look first
- Application entrypoint: `src/main/java/com/example/orderservice/OrderServiceApplication.java`
- Controller: `src/main/java/com/example/orderservice/controller/OrderController.java`
- Orchestration: `src/main/java/com/example/orderservice/service/QuoteService.java`, `src/main/java/com/example/orderservice/service/CheckoutService.java`
- Cart loading/enrichment: `src/main/java/com/example/orderservice/service/CartService.java`
- Pricing: `src/main/java/com/example/orderservice/service/PricingService.java`
- Promotions: `src/main/java/com/example/orderservice/service/promotion/PromotionEngine.java`
- Data sources: `src/main/java/com/example/orderservice/repository/CatalogRepository.java`, `src/main/java/com/example/orderservice/repository/PromotionRepository.java`
