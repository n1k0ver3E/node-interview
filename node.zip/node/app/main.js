const express = require("express");
const { router } = require("./api/routes");

const app = express();

app.use(express.json());
app.use(router);

const PORT = process.env.PORT || 3000;

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Commerce Checkout Service running on port ${PORT}`);
  });
}

module.exports = { app };
