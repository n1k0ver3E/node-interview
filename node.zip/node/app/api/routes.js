const express = require("express");
const { CatalogRepository } = require("../repositories/catalogRepo");
const { PromotionRepository } = require("../repositories/promoRepo");
const { OrderRepository } = require("../repositories/orderRepo");
const { CartService } = require("../services/cartService");
const { buildPromotionEngine } = require("../services/promotionEngine");
const { PricingService } = require("../services/pricingService");
const { ShippingService } = require("../services/shippingService");
const { QuoteService } = require("../services/quoteService");
const { CheckoutService } = require("../services/checkoutService");

const router = express.Router();

const catalogRepo = new CatalogRepository();
const promoRepo = new PromotionRepository();
const orderRepo = new OrderRepository();
const cartService = new CartService(catalogRepo);
const promotionEngine = buildPromotionEngine();
const pricingService = new PricingService({ promotionEngine, promotionRepository: promoRepo });
const shippingService = new ShippingService();
const quoteService = new QuoteService({ cartService, pricingService, shippingService });
const checkoutService = new CheckoutService({
  cartService,
  pricingService,
  shippingService,
  orderRepository: orderRepo,
});

function validateCartRequest(req, res, next) {
  const { items } = req.body;
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ detail: "Items are required" });
  }
  for (const item of items) {
    if (!item.sku || typeof item.sku !== "string") {
      return res.status(400).json({ detail: "Each item must have a sku" });
    }
    if (!item.quantity || typeof item.quantity !== "number" || item.quantity <= 0) {
      return res.status(400).json({ detail: "Each item must have a positive quantity" });
    }
  }
  next();
}

function validateOrderRequest(req, res, next) {
  const { email } = req.body;
  if (!email || typeof email !== "string" || !email.includes("@")) {
    return res.status(400).json({ detail: "A valid email is required" });
  }
  validateCartRequest(req, res, next);
}

router.post("/quote", validateCartRequest, (req, res) => {
  try {
    const result = quoteService.createQuote(req.body);
    res.json(result);
  } catch (err) {
    res.status(400).json({ detail: err.message });
  }
});

router.post("/orders", validateOrderRequest, (req, res) => {
  try {
    const result = checkoutService.placeOrder(req.body);
    res.json(result);
  } catch (err) {
    res.status(400).json({ detail: err.message });
  }
});

router.get("/admin/promotions", (req, res) => {
  const promotions = promoRepo.listActive().map((promo) => ({
    code: promo.code,
    kind: promo.kind,
    description: promo.description,
    percent_off: promo.percentOff ? promo.percentOff.toString() : null,
    eligible_skus: promo.eligibleSkus,
    eligible_categories: promo.eligibleCategories,
  }));
  res.json({ promotions });
});

module.exports = { router, cartService };
