const Decimal = require("decimal.js");
const { Promotion } = require("../models/domain");

class PromotionRepository {
  constructor() {
    this._promotions = {
      SAVE10: new Promotion({
        code: "SAVE10",
        kind: "order_percent",
        description: "10% off the whole order",
        percentOff: "10",
      }),
      APPAREL20: new Promotion({
        code: "APPAREL20",
        kind: "category_percent",
        description: "20% off apparel items",
        percentOff: "20",
        eligibleCategories: ["apparel"],
      }),
      MUGFAN: new Promotion({
        code: "MUGFAN",
        kind: "sku_percent",
        description: "25% off mugs",
        percentOff: "25",
        eligibleSkus: ["MUG"],
      }),
    };
  }

  getByCode(code) {
    if (!code) return null;
    return this._promotions[code.toUpperCase()] || null;
  }

  listActive() {
    return Object.values(this._promotions);
  }
}

module.exports = { PromotionRepository };
