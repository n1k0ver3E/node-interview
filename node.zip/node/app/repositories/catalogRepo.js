const Decimal = require("decimal.js");
const { Product, PriceTier } = require("../models/domain");

class CatalogRepository {
  constructor() {
    this._products = {
      TSHIRT: new Product({
        sku: "TSHIRT",
        name: "Logo T-Shirt",
        category: "apparel",
        basePrice: "20.00",
        priceTiers: [{ minQty: 3, unitPrice: "18.00" }],
        taxable: true,
        shippingClass: "apparel",
      }),
      MUG: new Product({
        sku: "MUG",
        name: "Ceramic Mug",
        category: "drinkware",
        basePrice: "16.00",
        priceTiers: [],
        taxable: true,
        shippingClass: "fragile",
      }),
      CAP: new Product({
        sku: "CAP",
        name: "Baseball Cap",
        category: "apparel",
        basePrice: "14.00",
        priceTiers: [],
        taxable: true,
        shippingClass: "apparel",
      }),
      STICKER: new Product({
        sku: "STICKER",
        name: "Sticker Pack",
        category: "accessories",
        basePrice: "4.00",
        priceTiers: [{ minQty: 10, unitPrice: "3.00" }],
        taxable: false,
        shippingClass: "light",
      }),
    };
    this.getProductCallCount = 0;
    this.getProductsBySkusCallCount = 0;
  }

  getProduct(sku) {
    this.getProductCallCount++;
    const product = this._products[sku];
    if (!product) {
      throw new Error(`Unknown SKU: ${sku}`);
    }
    return product;
  }

  getProductsBySkus(skus) {
    this.getProductsBySkusCallCount++;
    const result = {};
    for (const sku of skus) {
      result[sku] = this.getProduct(sku);
    }
    return result;
  }
}

module.exports = { CatalogRepository };
