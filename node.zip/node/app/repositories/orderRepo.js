class OrderRepository {
  constructor() {
    this._counter = 1001;
    this._orders = [];
  }

  save(order) {
    this._orders.push(order);
    return order;
  }

  nextId() {
    return `ORD-${this._counter++}`;
  }

  listOrders() {
    return [...this._orders];
  }
}

module.exports = { OrderRepository };
