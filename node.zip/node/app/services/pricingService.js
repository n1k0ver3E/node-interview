const Decimal = require("decimal.js");
const { PriceBreakdown } = require("../models/domain");
const { quantizeMoney } = require("../utils/money");

const TAX_RATES = {
  CA: new Decimal("0.0875"),
  NY: new Decimal("0.0880"),
  TX: new Decimal("0.0825"),
};

class PricingService {
  constructor({ promotionEngine, promotionRepository }) {
    this.promotionEngine = promotionEngine;
    this.promotionRepository = promotionRepository;
  }

  priceCart({ cart, couponCode, shippingCost, state }) {
    const subtotal = quantizeMoney(
      cart.items.reduce((sum, item) => sum.add(item.lineSubtotal), new Decimal("0.00"))
    );

    let appliedPromotions = [];
    let discount = new Decimal("0.00");
    const promotion = this.promotionRepository.getByCode(couponCode);
    if (couponCode && !promotion) {
      throw new Error(`Unknown coupon code: ${couponCode}`);
    }
    if (promotion) {
      const result = this.promotionEngine.apply(promotion, cart.items);
      discount = result.amount;
      appliedPromotions = result.appliedPromotions;
    }

    const taxableSubtotal = cart.items
      .filter((item) => item.taxable)
      .reduce((sum, item) => sum.add(item.lineSubtotal), new Decimal("0.00"));
    // Tax should apply after discount allocation, but current implementation simplifies
    // by taxing pre-discount taxable subtotal. Existing tests do not target this yet.
    const taxRate = TAX_RATES[state.toUpperCase()] || new Decimal("0.0500");
    const tax = quantizeMoney(taxableSubtotal.mul(taxRate));

    const total = quantizeMoney(subtotal.sub(discount).add(shippingCost).add(tax));
    return new PriceBreakdown({
      subtotal,
      discount: quantizeMoney(discount),
      shipping: quantizeMoney(shippingCost),
      tax,
      total,
      appliedPromotions,
    });
  }
}

module.exports = { PricingService };
