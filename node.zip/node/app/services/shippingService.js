const Decimal = require("decimal.js");
const { quantizeMoney } = require("../utils/money");

class ShippingService {
  calculate(cart) {
    const fragileCount = cart.items
      .filter((item) => item.shippingClass === "fragile")
      .reduce((sum, item) => sum + item.quantity, 0);
    const apparelCount = cart.items
      .filter((item) => item.shippingClass === "apparel")
      .reduce((sum, item) => sum + item.quantity, 0);
    const standardCount = cart.items
      .filter((item) => item.shippingClass === "standard")
      .reduce((sum, item) => sum + item.quantity, 0);
    const lightCount = cart.items
      .filter((item) => item.shippingClass === "light")
      .reduce((sum, item) => sum + item.quantity, 0);

    let shipping = new Decimal("5.00");
    shipping = shipping.add(new Decimal(fragileCount).mul("1.50"));
    shipping = shipping.add(new Decimal(apparelCount).mul("0.75"));
    shipping = shipping.add(new Decimal(standardCount).mul("1.00"));
    shipping = shipping.add(new Decimal(lightCount).mul("0.25"));

    const itemCount = cart.totalQuantity();
    if (itemCount >= 8) {
      shipping = shipping.sub("3.00");
    }

    return quantizeMoney(Decimal.max(shipping, new Decimal("0.00")));
  }
}

module.exports = { ShippingService };
