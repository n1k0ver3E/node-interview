const { quantizeMoney } = require("../utils/money");

class QuoteService {
  constructor({ cartService, pricingService, shippingService }) {
    this.cartService = cartService;
    this.pricingService = pricingService;
    this.shippingService = shippingService;
  }

  createQuote(request) {
    const cart = this.cartService.enrichItems(request.items);
    const shippingCost = this.shippingService.calculate(cart);
    const pricing = this.pricingService.priceCart({
      cart,
      couponCode: request.coupon_code || null,
      shippingCost,
      state: request.state || "CA",
    });
    return {
      items: cart.items.map((item) => ({
        sku: item.sku,
        name: item.productName,
        quantity: item.quantity,
        unit_price: item.effectiveUnitPrice.toFixed(2),
        line_subtotal: item.lineSubtotal.toFixed(2),
      })),
      subtotal: pricing.subtotal.toFixed(2),
      discount: pricing.discount.toFixed(2),
      shipping: pricing.shipping.toFixed(2),
      tax: pricing.tax.toFixed(2),
      total: pricing.total.toFixed(2),
      applied_promotions: pricing.appliedPromotions.map((promo) => ({
        code: promo.code,
        description: promo.description,
        amount: promo.amount.toFixed(2),
      })),
    };
  }
}

module.exports = { QuoteService };
