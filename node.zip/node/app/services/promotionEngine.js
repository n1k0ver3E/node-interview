const Decimal = require("decimal.js");
const { AppliedPromotion } = require("../models/domain");
const { quantizeMoney } = require("../utils/money");

class PromotionStrategy {
  get kind() {
    throw new Error("Not implemented");
  }

  apply(promotion, items) {
    throw new Error("Not implemented");
  }
}

class OrderPercentStrategy extends PromotionStrategy {
  get kind() {
    return "order_percent";
  }

  apply(promotion, items) {
    const subtotal = items.reduce((sum, item) => sum.add(item.lineSubtotal), new Decimal("0.00"));
    const percent = (promotion.percentOff || new Decimal("0")).div(100);
    const amount = quantizeMoney(subtotal.mul(percent));
    if (amount.lte(0)) {
      return { amount: new Decimal("0.00"), applied: null };
    }
    return {
      amount,
      applied: new AppliedPromotion({ code: promotion.code, description: promotion.description, amount }),
    };
  }
}

class CategoryPercentStrategy extends PromotionStrategy {
  get kind() {
    return "category_percent";
  }

  apply(promotion, items) {
    const eligibleTotal = items
      .filter((item) => promotion.eligibleCategories.includes(item.category))
      .reduce((sum, item) => sum.add(item.lineSubtotal), new Decimal("0.00"));
    const percent = (promotion.percentOff || new Decimal("0")).div(100);
    const amount = quantizeMoney(eligibleTotal.mul(percent));
    if (amount.lte(0)) {
      return { amount: new Decimal("0.00"), applied: null };
    }
    return {
      amount,
      applied: new AppliedPromotion({ code: promotion.code, description: promotion.description, amount }),
    };
  }
}

class SkuPercentStrategy extends PromotionStrategy {
  get kind() {
    return "sku_percent";
  }

  apply(promotion, items) {
    const eligibleTotal = items
      .filter((item) => promotion.eligibleSkus.includes(item.sku))
      .reduce((sum, item) => sum.add(item.lineSubtotal), new Decimal("0.00"));
    const percent = (promotion.percentOff || new Decimal("0")).div(100);
    const amount = quantizeMoney(eligibleTotal.mul(percent));
    if (amount.lte(0)) {
      return { amount: new Decimal("0.00"), applied: null };
    }
    return {
      amount,
      applied: new AppliedPromotion({ code: promotion.code, description: promotion.description, amount }),
    };
  }
}

class PromotionEngine {
  constructor(strategies) {
    this._strategies = {};
    for (const strategy of strategies) {
      this._strategies[strategy.kind] = strategy;
    }
  }

  apply(promotion, items) {
    const strategy = this._strategies[promotion.kind];
    if (!strategy) {
      throw new Error(`Unsupported promotion kind: ${promotion.kind}`);
    }
    const { amount, applied } = strategy.apply(promotion, items);
    if (!applied) {
      return { amount: new Decimal("0.00"), appliedPromotions: [] };
    }
    return { amount, appliedPromotions: [applied] };
  }
}

function buildPromotionEngine() {
  return new PromotionEngine([
    new OrderPercentStrategy(),
    new CategoryPercentStrategy(),
    new SkuPercentStrategy(),
  ]);
}

module.exports = { PromotionEngine, buildPromotionEngine };
