const { CartSnapshot, EnrichedCartLine } = require("../models/domain");

class CartService {
  constructor(catalogRepository) {
    this.catalogRepository = catalogRepository;
  }

  enrichItems(items) {
    const enriched = [];
    for (const item of items) {
      const product = this.catalogRepository.getProduct(item.sku);
      const unitPrice = product.unitPriceForQuantity(item.quantity);
      enriched.push(
        new EnrichedCartLine({
          sku: product.sku,
          productName: product.name,
          category: product.category,
          quantity: item.quantity,
          baseUnitPrice: product.basePrice,
          effectiveUnitPrice: unitPrice,
          taxable: product.taxable,
          shippingClass: product.shippingClass,
        })
      );
    }
    return new CartSnapshot({ items: enriched });
  }
}

module.exports = { CartService };
