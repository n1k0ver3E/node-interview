const Decimal = require("decimal.js");

class PriceTier {
  constructor({ minQty, unitPrice }) {
    this.minQty = minQty;
    this.unitPrice = new Decimal(unitPrice);
  }
}

class Product {
  constructor({ sku, name, category, basePrice, priceTiers = [], taxable = true, shippingClass = "standard" }) {
    this.sku = sku;
    this.name = name;
    this.category = category;
    this.basePrice = new Decimal(basePrice);
    this.priceTiers = priceTiers.map((t) => (t instanceof PriceTier ? t : new PriceTier(t)));
    this.taxable = taxable;
    this.shippingClass = shippingClass;
  }

  unitPriceForQuantity(quantity) {
    let unitPrice = this.basePrice;
    const sorted = [...this.priceTiers].sort((a, b) => a.minQty - b.minQty);
    for (const tier of sorted) {
      if (quantity >= tier.minQty) {
        unitPrice = tier.unitPrice;
      }
    }
    return unitPrice;
  }
}

class EnrichedCartLine {
  constructor({ sku, productName, category, quantity, baseUnitPrice, effectiveUnitPrice, taxable, shippingClass }) {
    this.sku = sku;
    this.productName = productName;
    this.category = category;
    this.quantity = quantity;
    this.baseUnitPrice = new Decimal(baseUnitPrice);
    this.effectiveUnitPrice = new Decimal(effectiveUnitPrice);
    this.taxable = taxable;
    this.shippingClass = shippingClass;
  }

  get lineSubtotal() {
    return this.effectiveUnitPrice.mul(this.quantity);
  }
}

class AppliedPromotion {
  constructor({ code, description, amount }) {
    this.code = code;
    this.description = description;
    this.amount = new Decimal(amount);
  }
}

class Promotion {
  constructor({ code, kind, description, percentOff = null, eligibleSkus = [], eligibleCategories = [] }) {
    this.code = code;
    this.kind = kind;
    this.description = description;
    this.percentOff = percentOff !== null ? new Decimal(percentOff) : null;
    this.eligibleSkus = eligibleSkus;
    this.eligibleCategories = eligibleCategories;
  }
}

class PriceBreakdown {
  constructor({ subtotal, discount, shipping, tax, total, appliedPromotions = [] }) {
    this.subtotal = new Decimal(subtotal);
    this.discount = new Decimal(discount);
    this.shipping = new Decimal(shipping);
    this.tax = new Decimal(tax);
    this.total = new Decimal(total);
    this.appliedPromotions = appliedPromotions;
  }
}

class OrderRecord {
  constructor({ orderId, email, couponCode = null, items, pricing }) {
    this.orderId = orderId;
    this.email = email;
    this.couponCode = couponCode;
    this.items = items;
    this.pricing = pricing;
  }
}

class CartSnapshot {
  constructor({ items }) {
    this.items = items;
  }

  totalQuantity() {
    return this.items.reduce((sum, item) => sum + item.quantity, 0);
  }

  *skus() {
    for (const item of this.items) {
      yield item.sku;
    }
  }
}

module.exports = {
  PriceTier,
  Product,
  EnrichedCartLine,
  AppliedPromotion,
  Promotion,
  PriceBreakdown,
  OrderRecord,
  CartSnapshot,
};
