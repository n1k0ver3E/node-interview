const Decimal = require("decimal.js");

Decimal.set({ rounding: Decimal.ROUND_HALF_UP });

const TWO_PLACES = 2;

function quantizeMoney(value) {
  return new Decimal(value).toDecimalPlaces(TWO_PLACES, Decimal.ROUND_HALF_UP);
}

module.exports = { quantizeMoney };
