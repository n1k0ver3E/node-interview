# Agent Guide for This Repository

## Project purpose
This is a small Express checkout service with quote and order APIs.

## Commands
- Install: `npm install`
- Run tests: `npm test`
- Run app: `npm start` or `npm run dev`

## Important constraints
- Keep public API response fields stable.
- Avoid adding external services or databases.

## Where to look first
- API entrypoint: `app/main.js`
- Routes: `app/api/routes.js`
- Orchestration: `app/services/quoteService.js`, `app/services/checkoutService.js`
- Cart loading/enrichment: `app/services/cartService.js`
- Pricing: `app/services/pricingService.js`
- Promotions: `app/services/promotionEngine.js`
- Data sources: `app/repositories/catalogRepo.js`, `app/repositories/promoRepo.js`
