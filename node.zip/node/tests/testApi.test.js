const request = require("supertest");
const { app } = require("../app/main");
const { cartService } = require("../app/api/routes");

describe("Commerce Checkout API", () => {
  test("basic quote without coupon", async () => {
    const response = await request(app)
      .post("/quote")
      .send({
        items: [
          { sku: "TSHIRT", quantity: 1 },
          { sku: "MUG", quantity: 1 },
        ],
        state: "CA",
      });
    expect(response.status).toBe(200);
    const data = response.body;
    expect(data.subtotal).toBe("36.00");
    expect(data.shipping).toBe("7.25");
    expect(data.tax).toBe("3.15");
    expect(data.total).toBe("46.40");
  });

  test("duplicate skus should use aggregate quantity for tier pricing", async () => {
    const response = await request(app)
      .post("/quote")
      .send({
        items: [
          { sku: "TSHIRT", quantity: 2 },
          { sku: "TSHIRT", quantity: 2 },
        ],
        state: "CA",
      });
    expect(response.status).toBe(200);
    const data = response.body;

    // Correct behavior: 4 shirts should unlock the 3+ tier, so all 4 should use $18.
    expect(data.subtotal).toBe("72.00");
    expect(data.items.map((item) => item.line_subtotal)).toEqual(["36.00", "36.00"]);
  });

  test("invalid coupon returns 400", async () => {
    const response = await request(app)
      .post("/quote")
      .send({
        items: [{ sku: "MUG", quantity: 1 }],
        coupon_code: "DOESNOTEXIST",
        state: "CA",
      });
    expect(response.status).toBe(400);
    expect(response.body.detail).toBe("Unknown coupon code: DOESNOTEXIST");
  });

  // test("product loading should batch by unique sku for large cart", async () => {
  //   cartService.catalogRepository.getProductCallCount = 0;
  //   cartService.catalogRepository.getProductsBySkusCallCount = 0;
  //
  //   const response = await request(app)
  //     .post("/quote")
  //     .send({
  //       items: [
  //         { sku: "TSHIRT", quantity: 1 },
  //         { sku: "TSHIRT", quantity: 2 },
  //         { sku: "MUG", quantity: 1 },
  //         { sku: "CAP", quantity: 1 },
  //         { sku: "CAP", quantity: 2 },
  //         { sku: "STICKER", quantity: 5 },
  //       ],
  //       state: "NY",
  //     });
  //
  //   expect(response.status).toBe(200);
  //   // Desired behavior: one batched fetch for unique SKUs, not one repository call per line.
  //   expect(cartService.catalogRepository.getProductsBySkusCallCount).toBe(1);
  //   expect(cartService.catalogRepository.getProductCallCount).toBeLessThanOrEqual(4);
  // });

  test("order endpoint works with coupon and returns order id", async () => {
    const response = await request(app)
      .post("/orders")
      .send({
        email: "candidate@example.com",
        items: [
          { sku: "TSHIRT", quantity: 1 },
          { sku: "CAP", quantity: 1 },
        ],
        coupon_code: "APPAREL20",
        state: "CA",
      });
    expect(response.status).toBe(200);
    const data = response.body;
    expect(data.order_id).toMatch(/^ORD-/);
    expect(data.discount).toBe("6.80");

    // Correct behavior taxes discounted taxable amount, not pre-discount subtotal.
    expect(data.tax).toBe("2.38");
    expect(data.total).toBe("36.08");
  });
});
